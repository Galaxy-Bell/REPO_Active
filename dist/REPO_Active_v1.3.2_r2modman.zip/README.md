﻿# REPO_Active

(Main README content should be here)

## Logging
This mod now creates a detailed log file to help with troubleshooting.
- **Log Directory:** BepInEx\config\REPO_Active\logs\
- **Log File:** A new file named REPO_Active_{timestamp}.log is created each time the game starts.
If you encounter issues, please upload this log file to the GitHub repository's 	est-logs directory.

---
## Logging & Troubleshooting
This mod creates a detailed log file to help with troubleshooting.
- **Log Directory:** BepInEx\config\REPO_Active\logs\
- **Log File:** A new file named REPO_Active_{timestamp}.log is created each time the game starts.
If you encounter issues where activation does not work, please check this log file for messages like [Not Ready], [manual] Skipped: ..., or [auto] No activatable point found. This will help identify the cause.
