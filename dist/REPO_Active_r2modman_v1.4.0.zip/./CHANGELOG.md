﻿# Changelog

## v1.4.0
- **Fix:** Implemented a state machine to prevent logic from running during level loading, fixing the "stuck on black screen" bug.
- **Fix:** Changed `ActivationKey` config to a string to ensure it appears in in-game config UIs.
- **Fix:** Activation is now confirmed by checking for a state change after `ButtonPress`, improving reliability.
- **Feature:** Added a file-based logger for diagnostics, controlled by the new `EnableDebugLog` config.
- **Enhancement:** Added experimental, best-effort RPC calls after activation to attempt to trigger game UI like map markers.
- **Enhancement:** Made player finding logic more robust and less performance-heavy.
- **Enhancement:** Made extraction point ID generation more stable.
- **Enhancement:** Refined logic for checking if a point is busy or activatable.
