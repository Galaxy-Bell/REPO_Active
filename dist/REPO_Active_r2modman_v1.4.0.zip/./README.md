﻿# REPO_Active v1.4.0

This version fixes critical bugs related to game loading freezes and activation failures. It introduces a proper state machine, a file logger for diagnostics, and more robust activation logic.

## Key Features
- **Host-Side Activation:** Only the host/MasterClient activates points to prevent network conflicts.
- **Dynamic Activation Algorithm:** Activates the nearest, available point, while strategically saving the extraction point closest to your spawn for last.
- **Multiplayer Discovery Sync:** When any player gets near an extraction point, its "discovered" status is synchronized to all other players using this mod via Photon events.
- **Configurable & UI-Friendly:**
  - `EnableAutoActivate` (true/false): Turns auto-activation on or off.
  - `ActivationKey` (string, e.g., "X"): Set your preferred key, fully editable in the in-game BepInEx config UI.
  - `RequireDiscovered` (true/false): If true, points must be discovered before being considered for activation.
  - `EnableDebugLog` (true/false): Enables detailed file logging to `BepInEx/plugins/REPO_Active/_logs/` for troubleshooting.

## Changes in v1.4.0
- **FIXED:** Resolved game loading hangs by implementing a state machine (`IsGameplayReady`) to defer all heavy logic until a gameplay scene is fully loaded.
- **FIXED:** `ActivationKey` config is a `string` and is fully editable in-game.
- **FIXED:** Activation is now confirmed by checking the point's state after `ButtonPress` is called, preventing the mod from getting stuck on unresponsive points.
- **ADDED:** A file logger for detailed diagnostics, controlled by the new `EnableDebugLog` config option.
- **ENHANCED:** Added best-effort RPC calls (`ButtonGoGreenRPC`, `StateSetRPC`) after activation to attempt to trigger in-game UI/map markers.
- **ENHANCED:** Player location logic is now more robust and less performance-intensive.
- **ENHANCED:** Point ID generation is more collision-resistant.
- **ENHANCED:** "Busy" and "Activatable" checks are more nuanced.
